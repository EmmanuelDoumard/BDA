#coding: latin-1

#Extraction d'un fichier csv en tuples

import csv
import vocabulary

tab_descripteurs=['Month','DayOfMonth','DayOfWeek','DepTime','ArrTime','AirTime','ArrDelay','DepDelay','Origin','Dest','Distance','TaxiIn','TaxiOut','CarrierDelay','WeatherDelay','SecurityDelay','LateAircraftDelay']

tab_sous_descripteurs=[]
Tab=[]
with open('extrait_2008.csv', 'r') as csvfile:
     reader = csv.reader(csvfile, delimiter=',', quotechar='|')
     for row in reader:
         Tab.append(row)

     

#Cette classe sert à la réécriture du texte, ligne par ligne, fourni dans le fichier source afin de pouvoir associer à chaque valeur un degré d'appartenance à l'ensemble flou associé
#t correspond à une ligne du fichier (format csv) d'entrée, découpée pour en faire un tableau.
#R correpond au vecteur de réécriture.
#voc correspond au vocabulaire à utiliser pour transformer les valeurs en degrés d'appartenance
class Reecriture:
    def __init__(self,t,voc):
        self._t=t
        self._voc=voc
        self.R=[]


    def getR(self):
        return self.R
        
    def getVoc(self):
        return self._voc

    def getT(self):
        return self._t

    #Cette procédure n'est appelée qu'une fois, lors de la réécriture de la première ligne, afin de définir un tableau global désignant les ensembles flous pour chaque attribut, aligné avec le partitionnement voulu.
    def init_tab_sous_descripteurs(self):
        for i in tab_descripteurs:
            tab_sous_descripteurs_tmp=[]
            partition=self.getVoc().getPartition(i)
            elements=partition.getElements()
            for elem in range(len(elements)):
                pe = partition.getElement(str(elem+1)) #pour avoir les éléments dans l'ordre...
                label=pe.getLabel()
                tab_sous_descripteurs_tmp.append(label)


            tab_sous_descripteurs.append(tab_sous_descripteurs_tmp)
         

    #Cette procédure transforme le tableau t (correspondant à une ligne du fichier d'entrée) en un vecteur de réécriture R, avec R[i][j] correspondant au degré d'appartenance de la valeur du tableau t correspondant à l'attribut i dans l'ensemble flou décrit par le terme j
    def reecrire(self):
        for i in tab_descripteurs:
            vect=[]
            num_att=self.getVoc().mapping(i)
            partition=self.getVoc().getPartition(i)
            elements=partition.getElements()
            for elem in range(len(elements)):
                pe = partition.getElement(str(elem+1)) #pour avoir les elements dans l'ordre...
                degre = pe.mu(self.getT()[num_att])
                vect.append(degre)
                
            self.R.append(vect)


#Cette classe permet de stocker l'ensemble des données reformulées grâce à la classe Reecriture et de les manipuler.
#R correspond au fichier d'entrée totalement reecrit, ligne par ligne, par la classe Reecriture.
#tabResume correspond au tableau résumant l'intégralité des données
#json correspond à la réécriture en json du résumé des données
#json2 correspond à la réécriture en json des règles d'association
class Data:
    def __init__(self,R):
        self._R=R
        self.tabResume=[]
        self.json=""
        self.json2=""
    
    
    def getR(self):
         return self._R

    def getTabResume(self):
         return self.tabResume

    def getJson(self):
         return self.json

    def getJson2(self):
         return self.json2

        
     
    def vive_le_json(self):
         self.json="{\n\"name\": \"resume\",\n\"children\":[\n"
         for i in range(len(self.getTabResume())):
              self.json+="{\n\"name\": \""+tab_descripteurs[i]+"\",\n\"children\": [\n"
              for j in range(len(self.getTabResume()[i])-1):
                   self.json+="{\"name\": \""+tab_sous_descripteurs[i][j]+"\",\"size\": "+str(self.getTabResume()[i][j])+"},\n"
          #ajout du dernier sans virgule
              if i != len(self.getTabResume())-1:
                   self.json+="{\"name\": \""+tab_sous_descripteurs[i][-1]+"\",\"size\": "+str(self.getTabResume()[i][-1])+"}\n]\n},\n"
              else:
                   self.json+="{\"name\": \""+tab_sous_descripteurs[i][-1]+"\",\"size\": "+str(self.getTabResume()[i][-1])+"}\n]\n}\n]\n}"

    def vive_le_json2(self):
         self.json2="{\n\"nodes\": [\n"
         for i in range(len(tab_descripteurs)):
              for j in range(len(tab_sous_descripteurs[i])):
                   if (i==len(tab_descripteurs)-1) & (j==len(tab_sous_descripteurs[i])-1):
                        self.json2+="{\"id\": \""+tab_descripteurs[i]+"."+tab_sous_descripteurs[i][j]+"\",\"group\":"+str(i)+"}\n],\n\"links\": [\n"
                        
                   else:
                        self.json2+="{\"id\": \""+tab_descripteurs[i]+"."+tab_sous_descripteurs[i][j]+"\",\"group\":"+str(i)+"},\n"

         for i in range(len(tab_descripteurs)):
              for j in range(len(tab_sous_descripteurs[i])):
                   for k in range(len(tab_descripteurs)):
                        for l in range(len(tab_sous_descripteurs[k])):
                             if(i!=k):
                                  if((i==len(tab_descripteurs)-1) & (k==i-1) & (j==len(tab_sous_descripteurs)-1) & (l==j)):
                                       self.json2+="{\"source\": \""+tab_descripteurs[i]+"."+tab_sous_descripteurs[i][j]+"\",\"target\":\""+tab_descripteurs[k]+"."+tab_sous_descripteurs[k][l]+"\",\"value\": "+ str(assoc([[i,j]],[k,l],self.getR()))+"}\n]\n}"
                                  else:
                                       if assoc([[i,j]],[k,l],self.getR())>0.8:
                                            self.json2+="{\"source\": \""+tab_descripteurs[i]+"."+tab_sous_descripteurs[i][j]+"\",\"target\":\""+tab_descripteurs[k]+"."+tab_sous_descripteurs[k][l]+"\",\"value\": "+ str(assoc([[i,j]],[k,l],self.getR()))+"},\n"
         




    def resume(self):
         self.tabResume=[]

         #On initialise le tableau du resume a la bonne taille
         for i in range(len(tab_descripteurs)):
              self.tabResume.append([0]*len(tab_sous_descripteurs[i]))

     
         for i in range(len(self.getR())):
              for j in range(len(self.getR()[i])):
                   for k in range(len(self.getR()[i][j])):
                        self.tabResume[j][k]+=self.getR()[i][j][k]/len(self.getR())



#Cette fonction réécrit R en Rv en ne prenant que les tuples où les termes ont un degré d'appartenance à tous les termes inclus dans v strictement supérieur à un seuil alpha
def Rv(R,v,alpha):
     TabRv=[]
     for i in range(len(R)):
         cool=True
         for terme in v:
              if R[i][terme[0]][terme[1]] <= alpha :
                   cool = False

         if cool:
              TabRv.append(R[i])

     return TabRv
          
            
#Cette fonction renvoie la couverture de v_prim sur R selon la définition du sujet (somme des degrés d'appartenance à v_prim divisé par le nombre de termes dans R)
def cover(v_prim,R):
     sum=0.0
     if len(R)>0:
          for i in range(len(R)):
               sum+=R[i][v_prim[0]][v_prim[1]]

          sum=sum/len(R)
     return sum

def dep(v,v_prim,R):
     RV = Rv(R,v,0)
     if cover(v_prim,R)>0:
          return cover(v_prim,RV)/cover(v_prim,R)
     else:
          return 0


#Cette fonction renvoie le degré d'association de v (pouvant comporter plusieurs termes) et v' (ne comportant qu'un terme) comme défini dans le sujet
def assoc(v,v_prim,R):
     if dep(v,v_prim,R) <= 1:
          return 0
     else :
          return (1-(1/dep(v,v_prim,R)))


               

          
#Cette fonction renvoie le degré d'atypicité d'un terme unaire v_prim.
def atypique(v_prim,R):
     cov=cover(v_prim,R)
     maxi=0
     if cov>0:
          for i in range(len(tab_sous_descripteurs[v_prim[0]])):
               v=[v_prim[0],i]
               if v!=v_prim:
                    mini=min(float(abs(v_prim[1]-i))/len(tab_sous_descripteurs[v_prim[0]]),cover(v,R),1-cov)
                    if mini>maxi:
                         maxi=mini

     return maxi


               
          
                              
if __name__ == "__main__":
    V=vocabulary.Vocabulary("FlightsVoc2.txt")
    RTab=[]
    R0=Reecriture(Tab[1],V)
    R0.init_tab_sous_descripteurs()
    R0.reecrire()
    RTab.append(R0.getR())
    for i in range(2,len(Tab)):
   	Ri=Reecriture(Tab[i],V)
   	Ri.reecrire()
   	RTab.append(Ri.getR())


    Flights=Data(RTab)
    Flights.resume()



    #Ce morceau de code teste toutes les associations de termes unaires. Comme il y en a beaucoup, on n'affiche que les termes dont le degré d'association est supérieur à un certain seuil.
    print("========Associativité========")
    for i in range(len(tab_descripteurs)):
         for j in range(len(tab_sous_descripteurs[i])):
              for k in range(len(tab_descripteurs)):
                   for l in range(len(tab_sous_descripteurs[k])):
                        if(i!=k):
                             if(assoc([[i,j]],[k,l],RTab)>0.9):
                                  test=assoc([[i,j]],[k,l],RTab)
                                  print(tab_descripteurs[i]+" "+tab_sous_descripteurs[i][j]+" -> "+tab_descripteurs[k]+" "+tab_sous_descripteurs[k][l]+" : "+str(test))

            


    print("\n========Atypicité========")
    for i in range(len(tab_descripteurs)):
         for j in range(len(tab_sous_descripteurs[i])):
              test2=atypique([i,j],RTab)
              if test2>0.39:
                   print(tab_descripteurs[i]+" "+tab_sous_descripteurs[i][j]+" est un terme atypique a un degre de : "+str(test2))


    


    Flights.vive_le_json()
    Flights.vive_le_json2()
    text_file = open("flare.json", "w")
    text_file.write(Flights.getJson())
    text_file.close()

    text_file = open("bula.json","w")
    text_file.write(Flights.getJson2())
    text_file.close()

